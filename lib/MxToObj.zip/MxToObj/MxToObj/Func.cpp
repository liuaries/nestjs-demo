#include "Func.h"

template<>
void ReadData(std::fstream &file, std::string &var)
{
	int32_t SaveNum(0);
	bool bUSC2(false);

	ReadData(file, SaveNum);

	if (SaveNum < 0)
	{
		bUSC2 = true;
		SaveNum = -SaveNum;
	}

	int strLength = 0;
	if (bUSC2)
	{
		strLength = SaveNum * sizeof(uint16_t);
		var.assign(strLength, '\0');
		file.read((char*)var.data(), strLength);
	}
	else
	{
		strLength = SaveNum * sizeof(uint8_t);
		var.assign(strLength, '\0');
		file.read((char*)var.data(), strLength);
	}
}
