﻿// MxToObj.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include "MxFileInfo.h"
#include "io.h"

int main(int argc, char** argv)
{

	if (argc < 3) 
	{
		return -1;
	}

	std::string command = argv[1];
	
	if (command == "-f") 
	{
		std::string mxFilePath = argv[2];
		std::string objFilePath;
		if (argc == 3) 
		{
			objFilePath = mxFilePath + ".obj";
		}
		else 
		{
			objFilePath = argv[3];
		}

		MxFileInfo mxFile;
		mxFile.LoadFile(mxFilePath);
		mxFile.ToObjFile(objFilePath);

		return 0;
	}
	else if(command == "-d")
	{
		std::string sourchPath = argv[2];
		std::string outputDir = argv[3];
		std::string startPath = sourchPath;
		sourchPath += "./*.mx";

		_finddata_t findData = { 0 };
		int result;
		intptr_t findHandle = _findfirst(sourchPath.c_str(), &findData);
		result = findHandle;
		while (result != -1)
		{
			if ((findData.attrib & _A_SUBDIR) != 0) 
			{
				continue;
			}

			std::string mxFilePath;
			mxFilePath = startPath + "/" + findData.name;
			std::string ObjFilePath = outputDir + "/" + findData.name + ".obj";

			MxFileInfo mxFile;
			mxFile.LoadFile(mxFilePath);
			mxFile.ToObjFile(ObjFilePath);

			result = _findnext(findHandle, &findData);
		}

		_findclose(findHandle);


		return 0;
	}
	
	return -1;
}


