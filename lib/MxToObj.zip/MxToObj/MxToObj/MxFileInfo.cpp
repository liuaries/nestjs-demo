#include "MxFileInfo.h"
#include "Func.h"

using namespace std;

bool MxFileInfo::LoadFile(const std::string & filePath)
{
	fstream mxFile;
	mxFile.open(filePath, fstream::in | fstream::binary);
	
	ReadData(mxFile, ResType);
	ReadData(mxFile, FingerMark);
	ReadData(mxFile, Id);
	ReadData(mxFile, Url);
	LoadHeader(mxFile);
	ReadContent(mxFile);

	return true;
}

void MxFileInfo::LoadHeader(std::fstream & file)
{
	ReadSourceSummary(file);
	ReadData(file, Header.Image.SizeX);
	ReadData(file, Header.Image.SizeY);
	int32_t NumBytes = 0;
	ReadData(file, NumBytes);
	ReadData(file, Header.Image.Data, NumBytes);

	int32_t NumModel = 0;
	ReadData(file, NumModel);
	Header.Models.assign(NumModel, FChunk());
	for (int i = 0; i < NumModel; ++i)
	{
		ReadData(file, Header.Models[i]);
	}

	int32_t NumMtrl = 0;
	ReadData(file, NumMtrl);
	Header.Materials.assign(NumMtrl, FChunk());
	for (int i = 0; i < NumMtrl; ++i)
	{
		ReadData(file, Header.Materials[i]);
	}

	int32_t NumTex = 0;
	ReadData(file, NumTex);
	Header.Textures.assign(NumTex, FChunk());
	for (int i = 0; i < NumTex; ++i)
	{
		ReadData(file, Header.Textures[i]);
	}
}

void MxFileInfo::ReadSourceSummary(std::fstream & file)
{
	ReadData(file, Header.HeadVersion);
	ReadData(file, Header.ResID);
	ReadData(file, Header.LocalVersion);
	ReadData(file, Header.bCompressed);
	ReadData(file, Header.ResourceName);

	if (Header.HeadVersion <= RESOURCE_HEADERVER_2)
	{
		int32_t	SizeX, SizeY, SizeZ;
		vector<char> Brand, Subfamily, CategoryName, Desc;
		uint8_t	PerfPosition;
		bool	bUsePhysics;
		ReadData(file, Brand);
		ReadData(file, Subfamily);
		ReadData(file, CategoryName);
		ReadData(file, PerfPosition);
		ReadData(file, bUsePhysics);
		ReadData(file, SizeX);
		ReadData(file, SizeY);
		ReadData(file, SizeZ);
		ReadData(file, Desc);
	}
	else if (Header.HeadVersion > RESOURCE_HEADERVER_2)
	{
		ReadData(file, Header.ModifyVersion);
	}

	int32_t numDeps = 0;
	ReadData(file, numDeps);
	Header.Dependences.assign(numDeps, "");
	for (int i = 0; i < numDeps; i++)
	{
		ReadData(file, Header.Dependences[i]);
	}

	ReadData(file, Header.BodyVersion);
}

void MxFileInfo::ReadContent(std::fstream & file)
{
	for (int i = 0; i < Header.Models.size(); i++) 
	{
		FChunk modelChunk = Header.Models[i];
		file.seekg(modelChunk.Offset);
		FModel model;
		model.LoadModel(file);

		Models.push_back(model);
	}

}

void MxFileInfo::ToObjFile(const std::string &saveFile)
{
	//fstream objFile(savePath, fstream::out|fstream::binary);

	vector<Vector> vertexData;
	vector<int32_t> FaceIndex;
	int32_t indexVertex = 1;
	for (int i = 0; i < Models.size(); ++i)
	{
		for (int j = 0; j < Models[i].Sections.size(); ++j)
		{
			Make_TarryVertex(vertexData, Models[i].Sections[j].ProcVertexBuffer);
			Make_TarryFaceIndex(FaceIndex, Models[i].Sections[j].ProcIndexBuffer, indexVertex);
			indexVertex = vertexData.size() + 1;
		}
	}

	SaveObjFile(saveFile, move(vertexData), move(FaceIndex));
}

void MxFileInfo::Make_TarryVertex(std::vector<Vector>& vertex, std::vector<FProcMeshVertex>& ProcVertexBuf)
{
	for (int i = 0; i < ProcVertexBuf.size(); ++i)
	{
		vertex.push_back(ProcVertexBuf[i].Position);
	}
}

void MxFileInfo::Make_TarryFaceIndex(std::vector<int32_t>& FaceIndex, std::vector<uint32_t>& ProcIndexBuffer, int32_t num)
{
	for (int i = 0; i < ProcIndexBuffer.size(); ++i)
	{
		FaceIndex.push_back(ProcIndexBuffer[i] + num);
	}
}

void MxFileInfo::SaveObjFile(const std::string &saveFile, std::vector<Vector>&& vertexArr, std::vector<int32_t>&& FaceIndex)
{
	fstream file(saveFile, fstream::out|fstream::binary);
	if (file)
	{
		for (int32_t i = 0; i < vertexArr.size(); ++i)
		{
			file << "v " << vertexArr[i].X << " " << vertexArr[i].Y << " " << vertexArr[i].Z << std::endl;
		}
		for (int32_t i = 0; i < FaceIndex.size(); i += 3)
		{
			file << "f " << FaceIndex[i + 2] << " " << FaceIndex[i + 1] << " " << FaceIndex[i] << std::endl;
		}
		file.close();
	}
}