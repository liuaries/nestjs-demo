#pragma once
#include <stdint.h>
#include <string>
#include <vector>
#include <fstream>
#include "Vector.h"


struct FProcMeshTangent
{
	Vector TangentX;
	int32_t bFlipTangentY;
};

struct FProcMeshVertex
{
	Vector Position;
	Vector Normal;
	FProcMeshTangent Tangent;
	Color Color;
	Vector2D UV0;
	Vector2D UV1;
	Vector2D UV2;
	Vector2D UV3;
};

struct FProcMeshSection
{
	std::vector<FProcMeshVertex> ProcVertexBuffer;
	std::vector<uint32_t> ProcIndexBuffer;
	Box SectionLocalBox;
	int32_t bEnableCollision;
	int32_t bSectionVisible;
};


class FModel 
{
public:
	std::string						ModelName;
	std::vector<int32_t>			RefMaterials;
	std::vector<FProcMeshSection>	Sections;
	//FConvexAggGeom					AggGeom;
	//FUCXData						UCXData;
	//Box								Bounds;
	
	void LoadModel(std::fstream &file);
	void SerializeMeshSection(std::fstream &file, FProcMeshSection &section);
	void SerializeVertex(std::fstream &file, FProcMeshVertex &vertex);
};

