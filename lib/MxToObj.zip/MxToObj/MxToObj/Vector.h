#pragma once
#include <stdint.h>

struct Vector 
{
	float X, Y, Z;
};

struct Vector2D 
{
	float X, Y;
};

struct Color 
{
	uint8_t R, G, B, A;
};

#pragma pack(push, 1)
struct Box
{
	Vector Min;
	Vector Max;
	uint8_t IsValid;
};
#pragma pack(pop)