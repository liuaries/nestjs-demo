#pragma once
#include <fstream>
#include <string>
#include <vector>

template<typename T>
void ReadData(std::fstream &file, T &var)
{
	file.read((char*)&var, sizeof(T));
}

template<>
void ReadData(std::fstream &file, std::string &var);

template<typename T>
void ReadData(std::fstream &file, std::vector<T> &var, int32_t num)
{
	var.assign(num, T());
	int dataLength = num * sizeof(T);
	file.read((char*)var.data(), dataLength);
}