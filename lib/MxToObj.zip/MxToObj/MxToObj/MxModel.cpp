#include "MxModel.h"
#include "Func.h"

void FModel::LoadModel(std::fstream &file)
{
	int32_t NumMtrl = 0;
	ReadData(file, NumMtrl);
	RefMaterials.assign(NumMtrl, 0);
	ReadData(file, RefMaterials, NumMtrl);

	int32_t	NumSection = 0;
	ReadData(file, NumSection);
	Sections.assign(NumSection, FProcMeshSection());
	for (int i = 0; i < Sections.size(); ++i)
	{
		SerializeMeshSection(file, Sections[i]);
	}
}


void FModel::SerializeMeshSection(std::fstream &file, FProcMeshSection &section)
{
	int32_t NumVerts = 0;
	ReadData(file, NumVerts);

	section.ProcVertexBuffer.assign(NumVerts, FProcMeshVertex());
	for (int i = 0; i < NumVerts; ++i)
	{
		FProcMeshVertex &Vert = section.ProcVertexBuffer[i];
		SerializeVertex(file, Vert);
	}

	int32_t NumIndices = 0;
	ReadData(file, NumIndices);
	section.ProcIndexBuffer.assign(NumIndices, 0);
	ReadData(file, section.ProcIndexBuffer, NumIndices);
	
	ReadData(file, section.SectionLocalBox);
	ReadData(file, section.bEnableCollision);
	ReadData(file, section.bSectionVisible);
}

void FModel::SerializeVertex(std::fstream &file, FProcMeshVertex &vertex)
{
	ReadData(file, vertex.Position);
	ReadData(file, vertex.Normal);
	ReadData(file, vertex.Tangent.bFlipTangentY);
	ReadData(file, vertex.Tangent.TangentX);
	ReadData(file, vertex.Color);
	ReadData(file, vertex.UV0);
}
