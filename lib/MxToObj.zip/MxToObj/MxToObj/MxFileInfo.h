#pragma once
#include <stdint.h>
#include <string>
#include <vector>
#include <fstream>
#include "MxModel.h"

#define  RESOURCE_HEADERVER_1	1			//->2	jason DRInfo
#define  RESOURCE_HEADERVER_2	2			//->3	Header 
#define  RESOURCE_HEADERVER		3

struct FChunk
{
	uint32_t		Offset;
	uint32_t		Size;
};

struct FResourceSummary
{
	int8_t						ResType;
	int32_t						HeadVersion;
	std::string					ResID;
	std::string					ResourceName;
	int32_t						LocalVersion;
	int32_t						ModifyVersion;
	uint8_t						bCompressed;
	std::vector<std::string>	Dependences;
	int32_t						BodyVersion;

	struct {
		int32_t					SizeX;
		int32_t					SizeY;
		std::vector<uint8_t>	Data;
	} Image;
};

struct FHeader : public FResourceSummary
{
	std::vector<FChunk>	Models;
	std::vector<FChunk>	Materials;
	std::vector<FChunk>	Textures;
};

class MxFileInfo
{
public:
	uint8_t				ResType;
	std::string			FingerMark;
	int32_t				Id;
	std::string			Url;
	FHeader				Header;
	std::vector<FModel> Models;

	bool LoadFile(const std::string &file);
	void ToObjFile(const std::string &savePath);

private:

	void LoadHeader(std::fstream &file);
	void ReadSourceSummary(std::fstream &file);
	void ReadContent(std::fstream &file);

	void Make_TarryVertex(std::vector<Vector>& vertex, std::vector<FProcMeshVertex>& ProcVertexBuf);
	void Make_TarryFaceIndex(std::vector<int32_t>& FaceIndex, std::vector<uint32_t>& ProcIndexBuffer, int32_t num);
	void SaveObjFile(const std::string &saveFile, std::vector<Vector>&& vertexArr, std::vector<int32_t>&& FaceIndex);

};